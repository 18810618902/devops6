#coding=utf-8
from django.views.generic import View, TemplateView
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect
from django.http.response import JsonResponse
from django.contrib.auth.mixins import LoginRequiredMixin
from django_otp import match_token, user_has_device, devices_for_user
 
class mylogin(TemplateView):
    template_name = 'ucenter/login.html'
    def get_context_data(self, **kwargs):
        kwargs['next'] = self.request.GET.get('next')
        return super(mylogin, self).get_context_data(**kwargs)
    def post(self, request):
        username = request.POST.get('username',None)
        password = request.POST.get('password',None)
        token = request.POST.get('token',None)
        user = authenticate(username=username, password=password)  # 验证django账户密码
        if user is None:
            return JsonResponse({'status':1})
        mttoken = match_token(user, token) 
        if mttoken is None:  # 验证动态码
            return JsonResponse({'status':2})
        login(request, user)
        next = request.get_full_path()
        return JsonResponse({'status':0, 'next':next})

class mylogout(LoginRequiredMixin, View):
    def get(self, request):
        logout(request)
        return HttpResponseRedirect("/login/?next=/")

class index_page(LoginRequiredMixin, TemplateView):
    template_name = 'index.html'
